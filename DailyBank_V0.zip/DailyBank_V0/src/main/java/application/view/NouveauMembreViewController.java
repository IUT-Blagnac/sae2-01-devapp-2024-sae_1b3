package application.view;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import application.DailyBankApp;
import application.DailyBankState;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

public class NouveauMembreViewController implements Initializable {

    private DailyBankApp runningMembre;
    private Stage fenetreNouveauMembre;

    private DailyBankState dailyBankState;
    private Stage stage;

    public void initContext(Stage stage, DailyBankState dailyBankState) {
        this.stage = stage;
        this.dailyBankState = dailyBankState;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        fenetreNouveauMembre.show();
        
    }

    public void setUpMembre(DailyBankApp runningMembre){
        this.runningMembre = runningMembre;
    }

        public void setFenetrePrincipale(Stage fenetreNouveauMembre) {
        this.fenetreNouveauMembre = fenetreNouveauMembre;
        this.fenetreNouveauMembre.setOnCloseRequest(event -> actionQuitter());
    }

    
    @FXML
    private void actionQuitter() {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Fermeture de l'application");
        confirm.setHeaderText("Voulez-vous quitter ");
        confirm.initOwner(this.fenetreNouveauMembre);

        ButtonType plustard = new ButtonType("Plus tard");
        confirm.getButtonTypes().setAll(plustard, ButtonType.YES, ButtonType.NO);

        Optional<ButtonType> reponse = confirm.showAndWait();

        if (reponse.orElse(null) == ButtonType.YES) {
            this.fenetreNouveauMembre.close();
        }
    }
}
